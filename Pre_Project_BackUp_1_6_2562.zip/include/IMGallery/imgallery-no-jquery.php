<?php 
$__jq=false;require_once("__main__.php"); 
?>