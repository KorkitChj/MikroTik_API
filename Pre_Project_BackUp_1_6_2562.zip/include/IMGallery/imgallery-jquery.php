<?php  
$__jq=true;require_once("__main__.php");  
?>