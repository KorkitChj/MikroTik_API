<?php
require('conn.php');	
    if(isset($_POST['submit'])){
        echo "<meta charset='utf-8'>" ;	
        $name=$_POST['name'];
        $session=$_POST['session'];
        $idle=$_POST['idle'];	
        $use=$_POST['use'];	
        $limit=$_POST['limit'];	
        $maccookie=$_POST['maccookie'];
        //$login="{:local date [/system clock get date ];:local time [/system clock get time ];:local uptime (".$uptime.");:if ( [/ip hotspot user get \$user comment ] = \"\" ) do={[/ip hotspot user set \$user comment=\$date];[/system scheduler add disabled=no interval=\$uptime name=\$user on-event= \"[/ip hotspot user remove [find where name=\$user]];[/ip hotspot active remove [find where user=\$user]];[/sys sch re [find where name=\$user]]\" start-date=\$date start-time=\$time]; }}";  
        if($name != ""){
                $ARRAY = $API->comm("/ip/hotspot/user/profile/add", array(
                                        "name" => $name,
                                        "session-timeout" => $session,
                                        "idle-timeout" => $idle,
                                        "shared-users" => $use,
                                        "mac-cookie-timeout" => $maccookie,
                                        "rate-limit" => $limit,
                                    ));		
                echo "<script>alert('ทำการเพิ่มแพคเกจเข้าระบบเรียบร้อยแล้ว.')</script>";
                echo "<meta http-equiv='refresh' content='0;url=profilestatus.php' />";
                exit;
            }
    }
?>