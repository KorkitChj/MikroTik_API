<?php	
	session_start();		
	require('../config/routeros_api.class.php');
	require('../include/connect_db_router.php');

	$API = new routeros_api();				
	//$API->debug = false;	
	//set_time_limit(160);

	$id=$_SESSION['cus_id'];	
	$sql = "SELECT * FROM location WHERE cus_id='".$id."'";
	$result=mysqli_query($link,$sql) or die("Could not connect");
	$rows=mysqli_fetch_array($result,MYSQLI_ASSOC);	
		$ip=$rows['ip_address'];
		$port=$rows['api_port'];
		$user=$rows['username'];
		$pass=$rows['password'];
		
		if ($API->connect($ip.":".$port,$user,$pass)) {
				
		}else{	
			echo "<script language='javascript'>alert('Disconnect')</script>";	
			echo "<meta http-equiv='refresh' content='0;url=../siteadmin/connectstatus.php'/>";
			exit(0);			
		}		
		
?>