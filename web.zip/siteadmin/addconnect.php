<?php
session_start();
require('../config/routeros_api.class.php');
require('../include/connect_db.php');
require('../template/template.html');
?>
<?php
if (!$_SESSION["cus_id"]) {
    Header("Location:../login.php");
} else { ?>
    <?php
  
    if (isset($_POST['connect'])) {
        $ipaddress = $_POST["ipaddress"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $portapi  = $_POST["portapi"];
        $namesite = $_POST["namesite"];
        $cus_id = $_SESSION["cus_id"];
     
        $result = $conn->query("SELECT * FROM location WHERE ip_address = '$ipaddress'");
        $num_rows = $result->num_rows;
        if ($num_rows == 0) {
            $sql = "INSERT INTO  location VALUES
            ('','$username','$password','$namesite','$portapi','$ipaddress','$cus_id')";
            if ($conn->query($sql)) {
                echo "<script language='javascript'>alert('บันทึกข้อมูลแล้ว')</script>";
                echo "<meta http-equiv=\"refresh\" content=\"0;url=connectstatus.php\">";
                exit(0);
            } else {
                echo "<script>alert('ตรวจสอบอีกครั้งไม่สามารถเพิ่มข้อมูลได้.');</script>";
                echo "<script>window.history.back()</script>";
                exit();
            }
        } else {
            echo "<script>alert(' IP/DNS มีอยู่แล้วในระบบ.');</script>";
            echo "<script>window.history.back()</script>";
            exit();
        }
        // $_SESSION["mp"] = $mp;
        // $_SESSION["username"] = $username;
        // $_SESSION["password"] = $password;
    }
    ?>
    <style>
        .container {
            background-color: white;
            padding: 20px;
        }
    </style>
    <title>Add Connect</title>
    <div class="container-fluid">
        <div class="row">
            <div class="col ">
            </div>
        </div>
        <div class="row">
            <div class="col ">
                <nav class="navbar fixed-top navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
                    <a class="navbar-brand" href="connectstatus.php"><span style="color:red">Site Admin</span><span style="color:blue">|</span><?php print_r($_SESSION["cus_name"]); ?></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item ">
                                <a href="connectstatus.php" class="nav-link ">
                                    <span class="badge badge-primary"><i class="fa fa-home"></i></span>
                                    หน้าหลัก</a>
                                </a>
                            </li>
                            <li class="nav-item active">
                                <a href="#" class="nav-link active">
                                    <span class="badge badge-primary"><i class="fas fa-hotel"></i></span>
                                    เพิ่มสถานบริการ</a>
                            </li>
                            <!-- <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-user"></i></span>
                                    พนักงานดูแล
                                </a>
                                <div class="dropdown-menu">
                                    <a href="employeestatus.php" class="dropdown-item">สถานะพนักงาน</a>
                                    <a href="addemployee.php" class="dropdown-item">เพิ่มพนักงาน</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-wifi"></i></span>
                                    Hotspot
                                </a>
                                <div class="dropdown-menu">
                                    <a href="profilestatus.php" class="dropdown-item">สถานะ Profile</a>
                                    <a href="addprofile.php" class="dropdown-item">เพิ่ม Profile</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-unlock"></i></span>
                                    ตั้งค่าเว็บไม่ต้อง Login
                                </a>
                                <div class="dropdown-menu">
                                    <a href="wallgardenstatus.php" class="dropdown-item">สถานะ</a>
                                    <a href="addwallgarden.php" class="dropdown-item">เพิ่ม</a>
                                </div>
                            </li> -->
                            <li class="nav-item">
                                <a href="changpwsite.php" class="nav-link ">
                                    <span class="badge badge-danger"><i class="fas fa-exchange-alt"></i></span>
                                    เปลี่ยนรหัสผ่าน</a>
                            </li>
                            <li class="nav-item">
                                <a href="cus_logout.php" class="nav-link " onclick="return confirm('ยืนยันการออกจากระบบ')">
                                    <span class="badge badge-danger"><i class="fas fa-sign-out-alt"></i></span>
                                    ออกจากระบบ</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    </div>


    <div class="container color-custom ">
        <div class="row">
            <div style="margin-left:25px;margin-top:-30px">
                <button type="button" class="btn btn-danger "><a style="color:white" href="connectstatus.php">รายการสถานะการเชื่อมต่อ</a></button>
            </div>
        </div>
        <div class="row">
            <div class="col d-flex justify-content-center">
                <p>
                    <h3 style="font-weight:bold">เพิ่มสถานบริการ</h3>
                </p>
            </div>
        </div>
        <div class="row ">
            <div class="col d-flex justify-content-center">
                <form action="" id="site" method="post">
                    <div class="form-group row">
                        <label for="ipaddress" class="col-sm-4 col-form-label">IP Address Or Domain Name: </label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control " name="ipaddress" placeholder="ไอพี หรือ โดเมนเนม" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="username" class="col-sm-4 col-form-label">Username:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="username" placeholder="ชื่อใช้งาน" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-sm-4 col-form-label">Password:</label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control" name="password" placeholder="รหัสผ่าน" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="portapi" class="col-sm-4 col-form-label">API Port:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="portapi" placeholder="พอร์ตเอพีไอ" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="namesite" class="col-sm-4 col-form-label">Site Name:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="namesite" placeholder="ชื่อไซต์งาน" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="b" class="col-sm-4 col-form-label"></label>
                        <div class="col-sm-8">
                            <button type="submit" name="connect" class="btn btn-primary">บันทึก</button>
                            <button type="bottom" class="btn btn-danger" onclick="window.location='connectstatus.php'">ยกเลิก</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>