<?php
session_start();
require('../include/connect_db.php');
require('../config/routeros_api.class.php');
require('../template/template.html');
?>
<?php
if (!$_SESSION["cus_id"]) {
    Header("Location:../login.php");
} else { ?>
    <style>
        .container {
            background-color: white;
            padding: 20px;
        }
    </style>
    <title>Employee Status</title>
    <div class="container-fluid">
        <div class="row">
            <div class="col ">
            </div>
        </div>
        <div class="row">
            <div class="col ">
                <nav class="navbar fixed-top navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
                    <a class="navbar-brand" href="../siteadmin/connectstatus.php"><span style="color:red">Site Admin</span><span style="color:blue">|</span><?php print_r($_SESSION["cus_name"]); ?></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item ">
                                <a href="../siteadmin/connectstatus.php" class="nav-link ">
                                    <span class="badge badge-primary"><i class="fa fa-home"></i></span>
                                    หน้าหลัก</a>
                                </a>
                            </li>
                            <li class="nav-item ">
                                <a href="../siteadmin/addconnect.php" class="nav-link ">
                                    <span class="badge badge-primary"><i class="fas fa-hotel"></i></span>
                                    เพิ่มสถานบริการ</a>
                            </li>
                            <li class="nav-item dropdown active">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-user"></i></span>
                                    พนักงานดูแล
                                </a>
                                <div class="dropdown-menu">
                                    <a href="#" class="dropdown-item active">สถานะพนักงาน</a>
                                    <a href="addemployee.php" class="dropdown-item">เพิ่มพนักงาน</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-wifi"></i></span>
                                    Hotspot
                                </a>
                                <div class="dropdown-menu">
                                    <a href="profilestatus.php" class="dropdown-item">สถานะ Profile</a>
                                    <a href="addprofile.php" class="dropdown-item">เพิ่ม Profile</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-unlock"></i></span>
                                    ตั้งค่าเว็บไม่ต้อง Login
                                </a>
                                <div class="dropdown-menu">
                                    <a href="wallgardenstatus.php" class="dropdown-item ">สถานะ</a>
                                    <a href="addwallgarden.php" class="dropdown-item">เพิ่ม</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="../siteadmin/changpwsite.php" class="nav-link ">
                                    <span class="badge badge-danger"><i class="fas fa-exchange-alt"></i></span>
                                    เปลี่ยนรหัสผ่าน</a>
                            </li>
                            <li class="nav-item">
                                <a href="../siteadmin/cus_logout.php" class="nav-link " onclick="return confirm('ยืนยันการออกจากระบบ')">
                                    <span class="badge badge-danger"><i class="fas fa-sign-out-alt"></i></span>
                                    ออกจากระบบ</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    </div>

    <div class="container color-custom ">
        <div class="row">
            <div style="margin-left:25px;margin-top:-30px">
                <button type="button" class="btn btn-info "><a style="color:white" href="addemployee.php">เพิ่มพนักงาน</a></button>
            </div>
        </div>
        <div class="row ">
            <div class="col d-flex justify-content-center">
                <!--หน้าถัดจากBrandner-->
                <p>
                    <h3 style="font-weight:bold">ข้อมูลพนักงานดูแลระบบ</h3>
                </p>
            </div>
        </div>
        <div class="row ">
            <div class="col">
                <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>Number</th>
                            <th>Site Name</th>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT a.working_site,b.full_name,b.username FROM location AS a INNER JOIN employee AS b
                        on a.location_id = b.location_id WHERE a.location_id = b.location_id";
                        $result = $conn->query($sql);
                        $n = 0;
                        while ($rows = $result->fetch_array(MYSQLI_ASSOC)) {
                            $n++;
                            echo "<tr id ='$n'>";
                            echo "<td>" . $n . "</td>";
                            echo "<td>" . $rows['working_site'] . "</td>";
                            echo "<td>" . $rows['full_name'] . "</td>";
                            echo "<td>" . $rows['username'] . "</td>";
                            echo "<td><button type=\"button\" data-toggle=\"modal\" data-target=\"#edit\" data-uid=\"1\" class=\"update btn btn-warning btn-sm\">
                                <span class=\"glyphicon glyphicon-cog\"></span></button></td>";
                            echo "<td><button type=\"button\" data-toggle=\"modal\" data-target=\"#delete\" data-uid=\"1\" class=\"delete btn btn-danger btn-sm\">
                                <span class=\"glyphicon glyphicon-trash\"></span></button></td>";
                            echo "</tr>";
                        }
                        $conn->close();
                        ?>
                        <!-- <tr id="d1">
                                <td>1</td>
                                <td id="s1">Reception</td>
                                <td id="f1">แดง มีชัย</td>
                                <td id="u1">Dang007</td>
                                <td><button type="button" data-toggle="modal" data-target="#edit" data-uid="1" class="update btn btn-warning btn-sm">
                                        <span class="glyphicon glyphicon-cog"></span></button></td>
                                <td><button type="button" data-toggle="modal" data-target="#delete" data-uid="1" class="delete btn btn-danger btn-sm">
                                        <span class="glyphicon glyphicon-trash"></span></button></td>
                            </tr> -->
                        <!-- <tr id="d2">
                                <td>2</td>
                                <td id="s1">fornt1</td>
                                <td id="f1">สมศรี มีสุขขี</td>
                                <td id="u1">Somsee008</td>
                                <td><button type="button" data-toggle="modal" data-target="#edit" data-uid="1" class="update btn btn-warning btn-sm">
                                        <span class="glyphicon glyphicon-cog"></span></button></td>
                                <td><button type="button" data-toggle="modal" data-target="#delete" data-uid="1" class="delete btn btn-danger btn-sm">
                                        <span class="glyphicon glyphicon-trash"></span></button></td>
                            </tr> -->
                    </tbody>
                </table>
            </div>
        </div>
        <div id="edit" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class=" modal-title">Update Data</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group row">
                            <label for="inputipaddress" class="col-sm-4 col-form-label">Full Name: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control " id="inputipaddress" placeholder="ชื่อพนักงาน" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputusername" class="col-sm-4 col-form-label">Username:</label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" id="inputusername" placeholder="ชื่อเข้าสู่ระบบ" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputpassword" class="col-sm-4 col-form-label">Password:</label>
                            <div class="col-sm-8">
                                <input type="password" class="form-control" id="inputpassword" placeholder="รหัสผ่าน" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputportapi" class="col-sm-4 col-form-label">Site:</label>
                            <div class="col-sm-8">
                                <select class="form-control">
                                    <option>Reception</option>
                                    <option>Front1</option>
                                    <option>Front2</option>
                                </select>
                            </div>
                        </div>
                        <!-- <input id="fname" type="text" class="form-control" name="fname" placeholder="Full Name">
                            <input id="uname" type="text" class="form-control" name="uname" placeholder="Username">
                            <input id="pword" type="password" class="form-control" name="pword" placeholder="Password">
                            <div class="dropdown ">
                                <button id="dLabel" name="dLabel" class="dropdown-select" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Select
                                    <span class="caret"></span>
                                </button>
                                <ul id="demolist" class="dropdown-menu" aria-labelledby="dLabel">
                                    <li>Reception</li>
                                    <li>Option 2</li>
                                    <li>Option 3</li>
                                    <li>Option 4</li>
                                    <li>Option 5</li>
                                    <li>Option 6</li>
                                </ul>
                            </div> -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="up" class="btn btn-warning" data-dismiss="modal">Update</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <div id="delete" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Delete Data</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <strong>Are you sure you want to delete this data?</strong>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="del" class="btn btn-danger" data-dismiss="modal">Delete</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                $('.dropdown-menu li').on('click', function() {
                    var getValue = $(this).text();
                    $('.dropdown-select').text(getValue);
                });
            });
            $(document).ready(function() {
                var getValue;
                $(".update ").click(function() {
                    var id = $(this).data("uid");
                    var s1 = $("#s1").html();
                    var f1 = $("#f1").html();
                    var u1 = $("#u1").html();
                    if (id == 1) {
                        $("#fname").val(f1);
                        $("#uname").val(u1);
                    }
                    $('#demolist li').on('click', function() {
                        getValue = $(this).text();
                    });
                    $("#up").click(function() {
                        // alert(getValue);
                        if (id == 1) {
                            var f1 = $("#fname").val();
                            var u1 = $("#uname").val();
                            $("#f1").html(f1);
                            $("#u1").html(u1);
                            $('#s1').html(getValue);
                        }

                    });
                });
                $(".delete").click(function() {
                    var id = $(this).data("uid");
                    $("#del").click(function() {
                        if (id == 1) {
                            $("#d1").html('');
                        }
                    });
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('#example').DataTable();
            });
        </script>
    </div>
<?php } ?>