<?php
session_start();
require('../include/connect_db.php');
require('../config/routeros_api.class.php');
require('../template/template.html');
?>
<?php
if (!$_SESSION["cus_id"]) {
    Header("Location:../login.php");
} else { ?>
    <style>
        .container {
            background-color: white;
            padding: 20px;
        }
    </style>
    <title>Add Employee</title>
    <?php
    if (isset($_POST["submit"])) {
        $name = $_POST["name"];
        $username = $_POST["username"];
        $password = MD5($_POST["password"]);
        $site = $_POST["site"];
        $sql = "SELECT username FROM employee WHERE username = '$username'";
        $result = $conn->query($sql);
        $num_rows = $result->num_rows;
        if($num_rows != 0){
            echo "<script>";
            echo "alert(\"username ไม่ถูกต้อง\");";
            echo "window.history.back()";
            echo "</script>";
        }else{
            $id = "SELECT location_id FROM location WHERE working_site = '$site'";
            $result = $conn->query($id);
            $rows = $result->fetch_array(MYSQLI_ASSOC);
            $loc = $rows['location_id'];
            $sql1 = "INSERT INTO employee VALUES ('','$username','$password','$name','$loc')";
            if($conn->query($sql1)){
                echo "<script language='javascript'>alert('บันทึกข้อมูลแล้ว')</script>";
                echo "<meta http-equiv=\"refresh\" content=\"0;url=employeestatus.php\">";
            }
        }
    }

    ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col ">
            </div>
        </div>
        <div class="row">
            <div class="col ">
                <nav class="navbar fixed-top navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
                    <a class="navbar-brand" href="../siteadmin/connectstatus.php"><span style="color:red">Site Admin</span><span style="color:blue">|</span><?php print_r($_SESSION["cus_name"]); ?></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item ">
                                <a href="../siteadmin/connectstatus.php" class="nav-link ">
                                    <span class="badge badge-primary"><i class="fa fa-home"></i></span>
                                    หน้าหลัก</a>
                                </a>
                            </li>
                            <li class="nav-item ">
                                <a href="../siteadmin/addconnect.php" class="nav-link ">
                                    <span class="badge badge-primary"><i class="fas fa-hotel"></i></span>
                                    เพิ่มสถานบริการ</a>
                            </li>
                            <li class="nav-item dropdown active">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-user"></i></span>
                                    พนักงานดูแล
                                </a>
                                <div class="dropdown-menu">
                                    <a href="employeestatus.php" class="dropdown-item ">สถานะพนักงาน</a>
                                    <a href="#" class="dropdown-item active">เพิ่มพนักงาน</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-wifi"></i></span>
                                    Hotspot
                                </a>
                                <div class="dropdown-menu">
                                    <a href="profilestatus.php" class="dropdown-item">สถานะ Profile</a>
                                    <a href="addprofile.php" class="dropdown-item">เพิ่ม Profile</a>
                                </div>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                                    <span class="badge badge-primary"><i class="fas fa-unlock"></i></span>
                                    ตั้งค่าเว็บไม่ต้อง Login
                                </a>
                                <div class="dropdown-menu">
                                    <a href="wallgardenstatus.php" class="dropdown-item ">สถานะ</a>
                                    <a href="addwallgarden.php" class="dropdown-item">เพิ่ม</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="../siteadmin/changpwsite.php" class="nav-link ">
                                    <span class="badge badge-danger"><i class="fas fa-exchange-alt"></i></span>
                                    เปลี่ยนรหัสผ่าน</a>
                            </li>
                            <li class="nav-item">
                                <a href="../siteadmin/cus_logout.php" class="nav-link " onclick="return confirm('ยืนยันการออกจากระบบ')">
                                    <span class="badge badge-danger"><i class="fas fa-sign-out-alt"></i></span>
                                    ออกจากระบบ</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    </div>

    <div class="container color-custom ">
        <div class="row">
            <div class="col d-flex justify-content-center">
                <p>
                    <h3 style="font-weight:bold">เพิ่มพนักงานดูแล</h3>
                </p>
            </div>
        </div>
        <div class="row ">
            <div class="col d-flex justify-content-center">
                <form action="#" method="post">
                    <div class="form-group row">
                        <label for="name" class="col-sm-4 col-form-label">Full Name: </label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control " name="name" placeholder="ชื่อพนักงาน" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="username" class="col-sm-4 col-form-label">Username:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="username" placeholder="ชื่อเข้าสู่ระบบ" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="password" class="col-sm-4 col-form-label">Password:</label>
                        <div class="col-sm-8">
                            <input type="password" class="form-control" name="password" placeholder="รหัสผ่าน" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="site" class="col-sm-4 col-form-label">Site:</label>
                        <div class="col-sm-8">
                            <select class="form-control" name="site">
                                <?php
                                $sql = "SELECT working_site FROM location";
                                $result = $conn->query($sql);
                                echo "<option value =''>กรุณาเลือกไซต์</option>";
                                while($rows = $result->fetch_array(MYSQLI_ASSOC)) {
                                    echo '<option value="'.$rows['working_site'].'">'.$rows['working_site'].'</option>';
                                }     
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="s" class="col-sm-4 col-form-label"></label>
                        <div class=" col-sm-8">
                            <button type="submit" name="submit" class="btn btn-primary">บันทึก</button>
                            <button type="bottom" class="btn btn-danger">ยกเลิก</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.dropdown-menu li').on('click', function() {
                var getValue = $(this).text();
                $('.dropdown-select').text(getValue);
            });
        });
    </script>
<?php } ?>