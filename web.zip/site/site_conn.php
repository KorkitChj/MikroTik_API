<?php
	session_start();
	if(!empty($_GET['location_id'])){
		$_SESSION['id']=$_GET['location_id'];	
	}	
		if($_GET['conn']=="connect") {	
			echo "<meta http-equiv='refresh' content='0;url=employeestatus.php' />";	
		}else{	
			echo "<script language='javascript'>alert('Disconnect')</script>";	
			echo "<script language='javascript'>window.location='../connectstatus.php'</script>";
			exit();
		}
?>