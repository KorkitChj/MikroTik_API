<?php
$link = mysqli_connect('localhost','root','','webapi') or die("Could not connect");
?>
