<?php
    $host ="localhost";
    $username = "root";
    $password = "";
    $dbname = "webapi";  
        $conn = new mysqli($host,$username,$password,$dbname) or die ("Could not connect");
?>